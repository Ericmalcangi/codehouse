# cliente/cliente.py

class Cliente:
    def __init__(self, nombre, apellido, email, telefono, direccion):
        """
        Constructor que inicializa los atributos del cliente.
        """
        self.nombre = nombre
        self.apellido = apellido
        self.email = email
        self.telefono = telefono
        self.direccion = direccion
        self.compras = []  # Lista para almacenar las compras del cliente

    def __str__(self):
        """
        Representación en cadena del objeto cliente.
        """
        return f"Cliente: {self.nombre} {self.apellido}\nEmail: {self.email}\nTeléfono: {self.telefono}\nDirección: {self.direccion}"

    def realizar_compra(self, producto):
        """
        Método para registrar una compra.
        """
        self.compras.append(producto)
        print(f"Compra de '{producto}' registrada para {self.nombre} {self.apellido}.")

    def mostrar_compras(self):
        """
        Método para mostrar las compras realizadas por el cliente.
        """
        if not self.compras:
            print(f"{self.nombre} {self.apellido} no ha realizado ninguna compra.")
        else:
            print(f"Compras realizadas por {self.nombre} {self.apellido}:")
            for compra in self.compras:
                print(f"- {compra}")
