from cliente.cliente import Cliente

# Crear un cliente
cliente1 = Cliente("Juan", "Pérez", "juan.perez@example.com", "123456789", "Calle Ficticia 123")

# Ver detalles del cliente
print(cliente1)

# Realizar compras
cliente1.realizar_compra("Laptop")
cliente1.realizar_compra("Móvil")

# Mostrar compras realizadas
cliente1.mostrar_compras()
