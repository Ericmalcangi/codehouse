# Proyecto primera pagina - CoderHouse Python

Este es un proyecto web desarrollado con **Django** que sigue el patrón **MVT** (Modelo-Vista-Template). El proyecto consiste en un blog donde los usuarios pueden crear posts, comentarlos y realizar búsquedas en la base de datos. Además, los posts están organizados en categorías y se pueden buscar por título.

## Requisitos

Este proyecto necesita tener instalados Python 3.8 o superior y Django 5.1. 

##
Estructura del Proyecto

Modelos:

Categoria: Define las categorías para los posts del blog.
Post: Representa un post o artículo del blog, con un título, contenido, fecha de publicación y categoría asociada.
Comentario: Representa los comentarios en los posts, con el nombre del comentarista, el contenido del comentario y la fecha del comentario.
Vistas:

Crear Post: Formulario para crear nuevos posts.
Listar Posts: Muestra una lista de todos los posts creados.
Buscar Posts: Permite buscar posts por título.
Crear Comentarios: Permite añadir comentarios a los posts.

Plantillas:

base.html: Plantilla base que contiene la estructura común (cabecera, pie de página, etc.).
listar_posts.html: Muestra todos los posts disponibles en la base de datos.
crear_post.html: Muestra el formulario para crear un nuevo post.
buscar_posts.html: Muestra el formulario de búsqueda y los resultados.

##
Instrucciones para Ejecutar el Proyecto
1. Configuración del Entorno
Asegúrate de tener Python 3.8 o superior instalado. Luego, crea un entorno virtual y activa el entorno:

python -m venv venv
source venv/bin/activate  # En Windows: venv\Scripts\activate

2. Probar la Funcionalidad
Inicia el servidor de desarrollo:

python manage.py runserver
