from django.shortcuts import render, redirect
from .models import Post, Categoria, Comentario
from .forms import PostForm, CategoriaForm, ComentarioForm, BusquedaForm


def listar_posts(request):
    posts = Post.objects.all()  
    return render(request, 'listar_posts.html', {'posts': posts})


def crear_post(request):
    if request.method == 'POST':
        form = PostForm(request.POST)
        if form.is_valid():
            form.save()  
            return redirect('listar_posts')  
    else:
        form = PostForm()  
    return render(request, 'crear_post.html', {'form': form})


def buscar_post(request):
    form = BusquedaForm(request.GET)  
    posts = []
    if form.is_valid():
        query = form.cleaned_data.get('query')  
        if query:
            posts = Post.objects.filter(titulo__icontains=query)  
    return render(request, 'buscar_post.html', {'form': form, 'posts': posts})
