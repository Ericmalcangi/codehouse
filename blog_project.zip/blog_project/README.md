# Blog App Django

Este es un proyecto de blog desarrollado con Django. Permite a los usuarios registrarse, iniciar sesión, crear, editar y eliminar publicaciones, así como editar su perfil de usuario.

## Funcionalidades

- **Autenticación de usuarios**: Registro, inicio de sesión, y cierre de sesión.
- **Gestión de publicaciones**:
  - Creación, edición y eliminación de publicaciones.
  - Visualización de detalles de publicaciones.
  - Subida de imágenes en las publicaciones.
- **Perfil de usuario**:
  - Visualización y edición del perfil del usuario (avatar, biografía, fecha de nacimiento).
  - Edición de campos como el nombre de usuario, primer nombre y apellido.
- **Interfaz en español**: El sitio se encuentra en español para facilitar su uso.

## Tecnologías

- **Django**: Framework web basado en Python.
- **SQLite**: Base de datos ligera (predeterminada de Django).
- **HTML/CSS**: Para el diseño de la interfaz de usuario.
- **Bootstrap (opcional)**: Para estilos rápidos y modernos.
- **Imágenes**: Los usuarios pueden subir imágenes para sus publicaciones y perfiles.

## Instalación

### Requisitos previos

Asegúrate de tener las siguientes herramientas instaladas:

- Python 3.x
- pip (para gestionar paquetes de Python)
- Django 5.x

