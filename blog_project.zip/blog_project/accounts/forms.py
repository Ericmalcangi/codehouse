from django import forms
from django.contrib.auth.models import User
from .models import Profile

class ProfileForm(forms.ModelForm):
    # Campos adicionales para modificar el nombre de usuario, primer nombre, apellido, y correo electrónico
    first_name = forms.CharField(max_length=100, required=False)
    last_name = forms.CharField(max_length=100, required=False)
    username = forms.CharField(max_length=150, required=False)
    email = forms.EmailField(max_length=255, required=False)  # Campo para el email

    class Meta:
        model = Profile
        fields = ['avatar', 'bio', 'birthday']

    # Inicializar los campos con los valores actuales del usuario
    def __init__(self, *args, **kwargs):
        user = kwargs.get('instance').user if kwargs.get('instance') else None
        super().__init__(*args, **kwargs)

        # Si el usuario existe, establecer los valores iniciales de los campos
        if user:
            self.fields['first_name'].initial = user.first_name
            self.fields['last_name'].initial = user.last_name
            self.fields['username'].initial = user.username
            self.fields['email'].initial = user.email  # Inicializamos el campo de email

    # Guardar los cambios en el perfil y el usuario
    def save(self, commit=True):
        profile = super().save(commit=False)

        # Guardar los datos del usuario
        user = profile.user
        user.first_name = self.cleaned_data.get('first_name')
        user.last_name = self.cleaned_data.get('last_name')
        user.username = self.cleaned_data.get('username')
        user.email = self.cleaned_data.get('email')  # Guardamos el email

        if commit:
            user.save()
            profile.save()

        return profile
