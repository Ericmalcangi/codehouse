# views.py
from django.contrib.auth.forms import UserCreationForm, AuthenticationForm
from django.contrib.auth import login, logout
from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from .forms import ProfileForm
from .models import Profile

# Vista para registrarse
def signup(request):
    if request.method == 'POST':
        form = UserCreationForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)
            return redirect('home')
    else:
        form = UserCreationForm()
    return render(request, 'signup.html', {'form': form})

# Vista para iniciar sesión
def login_view(request):
    if request.method == 'POST':
        form = AuthenticationForm(request, data=request.POST)
        if form.is_valid():
            user = form.get_user()
            login(request, user)
            return redirect('home')
    else:
        form = AuthenticationForm()
    return render(request, 'login.html', {'form': form})

# Vista para cerrar sesión
def logout_view(request):
    logout(request)
    return redirect('login')

# Vista para mostrar el perfil de usuario
@login_required
def profile(request):
    return render(request, 'profile.html')

# Vista para editar el perfil del usuario
@login_required
def profile_edit(request):
    # Si el usuario no tiene un perfil, lo creamos
    try:
        profile = request.user.profile
    except Profile.DoesNotExist:
        profile = Profile.objects.create(user=request.user)

    if request.method == 'POST':
        form = ProfileForm(request.POST, request.FILES, instance=profile)
        if form.is_valid():
            form.save()
            # Usamos el sistema de mensajes para mostrar un mensaje de éxito
            messages.success(request, 'Perfil actualizado con éxito!')
            return redirect('profile')  # Redirigimos al perfil del usuario después de guardar
    else:
        form = ProfileForm(instance=profile)

    return render(request, 'profile_edit.html', {'form': form})
