# blog_app/forms.py
from django import forms
from .models import Post

class PostForm(forms.ModelForm):
    class Meta:
        model = Post
        fields = ['title', 'author', 'content', 'image']

    image = forms.ImageField(required=False)  # Asegurarnos de que la imagen no sea obligatoria
