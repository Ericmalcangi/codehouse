# blog_app/views.py

from django.shortcuts import render, get_object_or_404, redirect
from .models import Post
from .forms import PostForm
from django.contrib.auth.decorators import login_required

# Vista de inicio (home)
def home(request):
    posts = Post.objects.all()
    return render(request, 'blog_app/home.html', {'posts': posts})

# Vista "Acerca de mí"
def about(request):
    return render(request, 'blog_app/about.html')

# Vista de detalle de la publicación
def post_detail(request, pk):
    post = get_object_or_404(Post, pk=pk)
    return render(request, 'blog_app/post_detail.html', {'post': post})

# Vista de creación de publicación (solo si el usuario está autenticado)
@login_required  # Solo usuarios autenticados pueden crear publicaciones
def post_create(request):
    if request.method == 'POST':
        form = PostForm(request.POST, request.FILES)  # Asegurarnos de que se manejan archivos
        if form.is_valid():
            post = form.save(commit=False)
            post.author = request.user  # Asociar el post con el usuario autenticado
            post.save()
            return redirect('home')
    else:
        form = PostForm()  # Si el método es GET, mostramos un formulario vacío

    return render(request, 'blog_app/post_create.html', {'form': form})

# Vista de actualización de publicación
def post_update(request, pk):
    post = get_object_or_404(Post, pk=pk)
    if request.method == 'POST':
        form = PostForm(request.POST, request.FILES, instance=post)
        if form.is_valid():
            form.save()
            return redirect('post_detail', pk=post.pk)
    else:
        form = PostForm(instance=post)
    
    return render(request, 'blog_app/post_update.html', {'form': form})

# Vista de eliminación de publicación
def post_delete(request, pk):
    post = get_object_or_404(Post, pk=pk)
    post.delete()
    return redirect('home')
